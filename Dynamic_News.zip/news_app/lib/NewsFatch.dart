import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart';
import 'package:news_app/newsArt.dart';
class FetchNews{

  static List sources = ["abc-news",

      "bbc-news",
      "bbc-sport",

      "business-insider",

      "engadget",
      "entertainment-weekly",
      "espn",
      "espn-cric-info",
      "financial-post",

      "fox-news",
      "fox-sports",
      "globo",
      "google-news",
      "google-news-in",

      "medical-news-today",

      "national-geographic",

      "news24",
      "new-scientist",

      "new-york-magazine",
      "next-big-future",

      "techcrunch",
      "techradar",

      "the-hindu",

      "the-wall-street-journal",

      "the-washington-times",
      "time",
      "usa-today",
    ];
    static Future <newsArt> fetchNews() async{
   final _random=new Random();
   var element= sources[_random.nextInt(sources.length)];

      print(element);
    Response response = await get(Uri.parse("https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=552283c0b32f4ec8a8d9ed55b97e98bd"));
 Map body_data = jsonDecode(response.body);
 List articles = body_data["articles"];
 print(body_data);
   final _Newrandom=new Random();
   var myArticle= articles[_random.nextInt(articles.length)];
     print(myArticle);
  return newsArt.fromAPItoApp(myArticle);


    }
}