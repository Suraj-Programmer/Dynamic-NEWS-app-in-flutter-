import 'package:flutter/material.dart';
import 'package:news_app/NewsContainer.dart';
import 'package:news_app/NewsFatch.dart';
import 'package:news_app/newsArt.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late newsArt  Newsart;
  Getnews() async{
    Newsart = await FetchNews.fetchNews();
    setState(() {

    });
  }
  void initState()
  {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView.builder(
          controller: PageController(),
          scrollDirection: Axis.vertical,
         onPageChanged: (value){
           var getnews = Getnews();
         },
          itemBuilder: (context, index)
          {

          FetchNews.fetchNews();

            return NewsContainer(
                imgurl:
                  Newsart.imgurl,
                newsHead: Newsart.newsHead,
                newsCnt:Newsart.newsCnt,
                   newsDes: Newsart.newsDes,
                   newsUrl: Newsart.newsUrl,
            );

          }), //page view scroll krne ke liye use krte he ek page se dusre page pe jane ke liye
    );
  }
}
