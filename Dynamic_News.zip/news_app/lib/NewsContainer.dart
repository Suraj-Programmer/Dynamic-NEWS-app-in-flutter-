import 'package:flutter/material.dart';

class NewsContainer extends StatelessWidget {
  String imgurl;
  String newsHead;
  String newsDes;
  String newsUrl;
  String newsCnt;


  NewsContainer(
      {Key? key,
        required this.imgurl,
        required this.newsDes,
        required this.newsCnt,
        required this.newsHead,
        required this.newsUrl})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: MediaQuery.of(context).size.height, // media query ka use hum display set krne ke liye krte he saare phone me kaisa bhi dimenesion ho sb me chale yeh app
        width: MediaQuery.of(context).size.width,
        // image :DecorationImage(
        //   image: DecorationImage(
        //     fit: BoxFit.cover,
        //   )
        // )
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Image.network( height: 400,
              width:MediaQuery.of(context).size.width,
              fit: BoxFit.cover, imgurl),
          SizedBox(height: 20,),
          Text(newsHead),
          Text
            ("${newsCnt.toString().substring(0,newsCnt.length-15)}",
            style: TextStyle(fontSize: 18),
          ),
          Spacer(),
          Row(
         mainAxisAlignment: MainAxisAlignment.end,   children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ElevatedButton(
                  onPressed: () {

                    print("Going to $newsUrl");
                  },
                  child:
                  Text("Read More"),

                ),
              ),
            ],
          ),
          SizedBox(height: 20,),
        ]),
      ),
    );
  }
}
